load('blur_data/A.mat');

sizeA = size(A);
fprintf('Size of A is %d x %d \n', sizeA(1), sizeA(2));