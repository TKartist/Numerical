function [Spec_nodes,Kmeans_nodes] = ClusterMetrics(K,x_spec,x_kmeans)
%% METRICS
Spec_nodes   = 0;
Kmeans_nodes = 0;

 % 2c) Calculate the number of nodes per cluster (for k-means and spectral
 %     clustering) and plot them in a histogram.
 
% \----------------------------/
%     Your implementation
% \----------------------------/
 
end